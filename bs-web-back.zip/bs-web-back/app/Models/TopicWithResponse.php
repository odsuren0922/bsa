<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TopicWithResponse extends Model
{
    protected $table = 'topic_with_responses';
    public $timestamps = false;
}


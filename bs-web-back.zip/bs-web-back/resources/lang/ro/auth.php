<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'failed' => 'Credentialele nu au fost gasite.',
    'throttle' => 'Prea multe incercari de conectare. Va rugam sa incercati din nou in :seconds secunde.',

];

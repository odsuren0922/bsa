@readonly
    <x-utils.alert type="info" class="alert-header" :dismissable="false" class="pt-1 pb-1 mb-0">
        @lang('The Application is currently in read only mode. All requests other than GET are disabled.')
    </x-utils.alert>
@endreadonly
